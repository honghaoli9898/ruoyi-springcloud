# coding=utf-8
from resource_management.libraries.script.script import Script
from resource_management.core.source import InlineTemplate
from resource_management.core.resources.system import Directory,Execute, File
import os,sys,codecs,time,re
from resource_management.libraries.functions.check_process_status import check_process_status
from resource_management.core.exceptions import ComponentIsNotRunning
from resource_management.core.logger import Logger
from resource_management import *

reload(sys)
sys.setdefaultencoding('utf8')

class SclickhouseMaster(Script):
    def install(self, env):
        import params
        Logger.info("====== install sclickhouse start ======")
        # add user
        clickhouse_userid = os.popen("id -u %s" % params.sclickhouse_user).readline().strip("\n")
        if clickhouse_userid == '':
            Logger.info("====== add clickhouse user ======")
            Execute('useradd ' + params.sclickhouse_user, user='root')

        clickhouse_bridge_userid = os.popen("id -u %s" % 'clickhouse-bridge').readline().strip("\n")
        if clickhouse_bridge_userid == '':
            Logger.info("====== add clickhouse-bridge user ======")
            Execute('useradd ' + 'clickhouse-bridge', user='root')

        if not os.path.exists(params.install_dir):
            Execute('mkdir -p ' + params.install_dir, user='root', ignore_failures=True)

        if not os.path.exists(params.install_dir+'/bin'):
            Logger.info("====== downloaded "+ params.package_name+" from "+params.sclickhouse_download_url+"  ======")
            Execute('wget ' + params.sclickhouse_download_url + ' -O ' + params.sclickhouse_package_tmp_file, user=params.sclickhouse_user)

            # extract authorization
            Execute('tar -zxvf {0} -C {1}'.format(params.sclickhouse_package_tmp_file, params.install_dir), user='root',ignore_failures=True)
            Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, params.install_dir) , user='root')
            Execute('chmod -R 755 {0}/bin/*'.format(params.install_dir), user='root')
        # pid dir
        Execute('mkdir -p /var/run/clickhouse-server', user='root', ignore_failures=True)
        Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, '/var/run/clickhouse-server'), user='root')
        # log dir
        Execute('mkdir -p ' + params.logger_dir, user='root', ignore_failures=True)
        Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, params.logger_dir),user='root', ignore_failures=True)
        # data dir
        Execute('mkdir -p ' + params.data_path, user='root', ignore_failures=True)
        Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, params.data_path),user='root', ignore_failures=True)
        # clickhouse config dir
        Execute('ln -s {0}/etc /etc/clickhouse-server'.format(params.install_dir), user='root', ignore_failures=True)
        Execute('chown -R {0}:{1} /etc/clickhouse-server'.format(params.sclickhouse_user, params.sclickhouse_group),user='root', ignore_failures=True)

        # clickhouse bin
        Execute('ln -s {0}/bin/clickhouse /usr/bin/clickhouse-server'.format(params.install_dir), user='root', ignore_failures=True)
        Execute('ln -s {0}/bin/clickhouse /usr/bin/clickhouse'.format(params.install_dir), user='root', ignore_failures=True)

        if os.path.exists(params.sclickhouse_package_tmp_file):
            os.remove(params.sclickhouse_package_tmp_file)
        self.configure(env)

        Logger.info("====== install sclickhouse stop ======")

    def configure(self, env):
        import params
        env.set_params(params)
        Logger.info("====== start configure sclickhouse ======")
        Logger.info("====== delete [config.xml] file")
        File(os.path.join(params.config_dirtory, 'config.xml'),
             action="delete",
             owner='root'
             )
        Logger.info("====== create [config.xml] file")
        File(os.path.join(params.config_dirtory, 'config.xml'),
             owner=params.sclickhouse_user,
             group=params.sclickhouse_group,
             mode=0755,
             content=Template("config.xml.j2")
             )

        Logger.info("====== delete [metrika.xml] file")
        File(os.path.join(params.config_dirtory, 'metrika.xml'),
             action="delete",
             owner='root'
             )
        Logger.info("====== create [metrika.xml] file")
        File(os.path.join(params.config_dirtory, 'metrika.xml'),
             owner=params.sclickhouse_user,
             group=params.sclickhouse_group,
             mode=0755,
             content=Template("metrika.xml.j2")
             )

        Logger.info("====== end configure sclickhouse ======")

    def start(self, env):
        import params
        self.configure(env)
        Execute(params.install_dir + '/bin/clickhouse start', user='clickhouse')

    def stop(self, env):
        import params
        self.configure(env)
        Execute(params.install_dir + '/bin/clickhouse stop', user='clickhouse')

    def restart(self, env):
        import params
        self.configure(env)
        Execute(params.install_dir + '/bin/clickhouse restart', user='clickhouse')

    def status(self,env):
        import params
        env.set_params(params)
        Logger.info("sclickhouse pid file:"+params.sclickhouse_pid_file)
        check_process_status(params.sclickhouse_pid_file)

if __name__ == "__main__":
    SclickhouseMaster().execute()