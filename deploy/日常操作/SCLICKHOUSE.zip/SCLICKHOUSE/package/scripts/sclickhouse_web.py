# coding=utf-8
from resource_management.libraries.script.script import Script
from resource_management.core.source import InlineTemplate
from resource_management.core.resources.system import Directory,Execute, File
import os,sys,codecs,time,re
from resource_management.libraries.functions.check_process_status import check_process_status
from resource_management.core.exceptions import ComponentIsNotRunning
from resource_management.core.logger import Logger
from resource_management import *

reload(sys)
sys.setdefaultencoding('utf8')

class SclickhouseWeb(Script):
    def install(self, env):
        import params
        Logger.info("====== install sclickhouse web start ======")
        # add user
        clickhouse_userid = os.popen("id -u %s" % params.sclickhouse_user).readline().strip("\n")
        if clickhouse_userid == '':
            Logger.info("====== add clickhouse user ======")
            Execute('useradd ' + params.sclickhouse_user, user='root')

        clickhouse_bridge_userid = os.popen("id -u %s" % 'clickhouse-bridge').readline().strip("\n")
        if clickhouse_bridge_userid == '':
            Logger.info("====== add clickhouse-bridge user ======")
            Execute('useradd ' + 'clickhouse-bridge', user='root')

        if not os.path.exists(params.web_install_dir):
            Execute('mkdir -p ' + params.web_install_dir, user='root', ignore_failures=True)

        if not os.path.exists(params.web_install_dir+'/nginx'):
            Logger.info("====== downloaded "+ params.web_package_name+" from "+params.sclickhouse_web_download_url+"  ======")
            Execute('wget ' + params.sclickhouse_web_download_url + ' -O ' + params.sclickhouse_web_package_tmp_file, user=params.sclickhouse_user)

            # extract authorization
            Execute('tar -zxvf {0} -C {1}'.format(params.sclickhouse_web_package_tmp_file, params.web_install_dir), user='root',ignore_failures=True)
            Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, params.web_install_dir) , user='root')
            Execute('chmod -R 755 {0}/bin/*'.format(params.web_install_dir), user='root')
        # pid dir
        Execute('mkdir -p ' + params.sclickhouse_web_pid_dir, user='root', ignore_failures=True)
        Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, params.sclickhouse_web_pid_dir), user='root')
        # log dir
        Execute('mkdir -p ' + params.web_sclickhouse_log_dir, user='root', ignore_failures=True)
        Execute('chown -R {0}:{1} {2}'.format(params.sclickhouse_user, params.sclickhouse_group, params.web_sclickhouse_log_dir),user='root', ignore_failures=True)
        Execute('mkdir -p /usr/local/nginx/logs', user='root', ignore_failures=True)
        Execute('chmod -R 777 /usr/local/nginx/logs', user='root', ignore_failures=True)

        if os.path.exists(params.sclickhouse_web_package_tmp_file):
            os.remove(params.sclickhouse_web_package_tmp_file)
        self.configure(env)

        Logger.info("====== install sclickhouse web stop ======")

    def configure(self, env):
        import params
        env.set_params(params)
        Logger.info("====== start configure sclickhouse web ======")
        Logger.info("====== delete [nginx.conf] file")
        File(os.path.join(params.web_install_dir + '/nginx/conf', 'nginx.conf'),
             action="delete",
             owner='root'
             )
        Logger.info("====== create [nginx.conf] file")
        File(os.path.join(params.web_install_dir + '/nginx/conf', 'nginx.conf'),
             owner=params.sclickhouse_user,
             group=params.sclickhouse_group,
             mode=0755,
             content=Template("nginx.conf.j2")
             )

        Logger.info("====== end configure sclickhouse web ======")

    def start(self, env):
        import params
        self.configure(env)
        Execute(params.web_install_dir + '/nginx/sbin/nginx -c ' + params.web_install_dir +'/nginx/conf/nginx.conf', user='clickhouse')

    def stop(self, env):
        import params
        self.configure(env)
        Execute(params.web_install_dir + '/nginx/sbin/nginx -c '+ params.web_install_dir +'/nginx/conf/nginx.conf'+' -s stop', user='clickhouse')

    def restart(self, env):
        import params
        self.configure(env)
        Execute(params.web_install_dir + '/nginx/sbin/nginx -c '+ params.web_install_dir +'/nginx/conf/nginx.conf'+' -s reload', user='clickhouse')

    def status(self,env):
        import params
        env.set_params(params)
        Logger.info("sclickhouse web pid file:"+params.sclickhouse_web_pid_file)
        check_process_status(params.sclickhouse_web_pid_file)

if __name__ == "__main__":
    SclickhouseWeb().execute()