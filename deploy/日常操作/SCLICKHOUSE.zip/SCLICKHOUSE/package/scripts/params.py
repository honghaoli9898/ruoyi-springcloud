# coding=utf-8
import os
import json
import socket
import sys
from resource_management.libraries.script import Script
from resource_management.libraries.functions.format import format
from resource_management.libraries.functions.default import default

reload(sys)
sys.setdefaultencoding('utf8')

config = Script.get_config()

stack_root = '/usr/hdp'
current_version = '3.1.5.0-152'
base_dir = stack_root + '/' +current_version
component_name = 'sclickhouse'

#用户和用户组
sclickhouse_user = config['configurations']['sclickhouse-env']['sclickhouse_user']
sclickhouse_group = config['configurations']['sclickhouse-env']['sclickhouse_group']

#sclickhouse安装包名称
package_name = config['configurations']['install-info']['package_name']
#sclickhouse安装目录
install_dir = config['configurations']['install-info']['install_dir']


yum_repository_host = 'master'
sclickhouse_download_url = "http://"+yum_repository_host+"/Seabox-SDP-3.1.5/sclickhouse/" + package_name
sclickhouse_package_tmp_file = '/tmp/{}'.format(package_name)
config_dirtory = install_dir + '/etc'

#sclickhouse数据目录
data_path = config['configurations']['config']['path']
#sclickhouse日志目录
logger_dir = config['configurations']['config']['logger_dir']
#sclickhouse pid文件
sclickhouse_pid_file = '/var/run/clickhouse-server/clickhouse-server.pid'


#sclickhouse web安装包名称
web_package_name = config['configurations']['sclickhouse-web']['sclickhouse_web_package_name']
#sclickhouse web安装目录
web_install_dir = config['configurations']['sclickhouse-web']['sclickhouse_web_install_dir']
#sclickhouse web日志目录
web_sclickhouse_log_dir = config['configurations']['sclickhouse-web']['sclickhouse_web_log_dir']
#sclickhouse web pid文件
sclickhouse_web_pid_dir = config['configurations']['sclickhouse-web']['sclickhouse_web_pid_dir']
sclickhouse_web_pid_file_name = config['configurations']['sclickhouse-web']['sclickhouse_web_pid_file_name']
sclickhouse_web_pid_file = sclickhouse_web_pid_dir + '/' + sclickhouse_web_pid_file_name
#sclickhouse web下载地址
sclickhouse_web_download_url = "http://"+yum_repository_host+"/Seabox-SDP-3.1.5/sclickhouse/" + web_package_name
#sclickhouse web临时目录
sclickhouse_web_package_tmp_file = '/tmp/{}'.format(web_package_name)






#配置文件config.xml.j2参数变量
logger_level = config['configurations']['config']['logger_level']
logger_log_dir = config['configurations']['config']['logger_log_dir']
logger_errorlog_dir = config['configurations']['config']['logger_errorlog_dir']
logger_rotation_policy_size = config['configurations']['config']['logger_rotation_policy_size']
logger_rotation_policy_count = config['configurations']['config']['logger_rotation_policy_count']
clickhouse_client_display_name = config['configurations']['config']['clickhouse_client_display_name']
http_port = config['configurations']['config']['http_port']
tcp_port = config['configurations']['config']['tcp_port']
mysql_port = config['configurations']['config']['mysql_port']
postgresql_port = config['configurations']['config']['postgresql_port']
interserver_http_port = config['configurations']['config']['interserver_http_port']
listen_host = config['configurations']['config']['listen_host']
max_connections = config['configurations']['config']['max_connections']
keep_alive_timeout = config['configurations']['config']['keep_alive_timeout']
grpc_enable_ssl = config['configurations']['config']['grpc_enable_ssl']
grpc_ssl_cert_file = config['configurations']['config']['grpc_ssl_cert_file']
grpc_ssl_key_file = config['configurations']['config']['grpc_ssl_key_file']
grpc_ssl_require_client_auth = config['configurations']['config']['grpc_ssl_require_client_auth']
grpc_ssl_ca_cert_file = config['configurations']['config']['grpc_ssl_ca_cert_file']
grpc_compression = config['configurations']['config']['grpc_compression']
grpc_compression_level = config['configurations']['config']['grpc_compression_level']
grpc_max_send_message_size = config['configurations']['config']['grpc_max_send_message_size']
grpc_max_receive_message_size = config['configurations']['config']['grpc_max_receive_message_size']
grpc_verbose_logs = config['configurations']['config']['grpc_verbose_logs']
openSSL_server_certificateFile = config['configurations']['config']['openSSL_server_certificateFile']
openSSL_server_privateKeyFile = config['configurations']['config']['openSSL_server_privateKeyFile']
openSSL_server_dhParamsFile = config['configurations']['config']['openSSL_server_dhParamsFile']
openSSL_server_verificationMode = config['configurations']['config']['openSSL_server_verificationMode']
openSSL_server_loadDefaultCAFile = config['configurations']['config']['openSSL_server_loadDefaultCAFile']
openSSL_server_cacheSessions = config['configurations']['config']['openSSL_server_cacheSessions']
openSSL_server_disableProtocols = config['configurations']['config']['openSSL_server_disableProtocols']
openSSL_server_preferServerCiphers = config['configurations']['config']['openSSL_server_preferServerCiphers']
openSSL_client_loadDefaultCAFile = config['configurations']['config']['openSSL_client_loadDefaultCAFile']
openSSL_client_cacheSessions = config['configurations']['config']['openSSL_client_cacheSessions']
openSSL_client_disableProtocols = config['configurations']['config']['openSSL_client_disableProtocols']
openSSL_client_preferServerCiphers = config['configurations']['config']['openSSL_client_preferServerCiphers']
openSSL_client_verificationMode = config['configurations']['config']['openSSL_client_verificationMode']
http_server_default_response = config['configurations']['config']['http_server_default_response']
max_concurrent_queries = config['configurations']['config']['max_concurrent_queries']
max_server_memory_usage = config['configurations']['config']['max_server_memory_usage']
max_thread_pool_size = config['configurations']['config']['max_thread_pool_size']
max_server_memory_usage_to_ram_ratio = config['configurations']['config']['max_server_memory_usage_to_ram_ratio']
total_memory_profiler_step = config['configurations']['config']['total_memory_profiler_step']
total_memory_tracker_sample_probability = config['configurations']['config']['total_memory_tracker_sample_probability']
max_open_files = config['configurations']['config']['max_open_files']
uncompressed_cache_size = config['configurations']['config']['uncompressed_cache_size']

mark_cache_size = config['configurations']['config']['mark_cache_size']
mmap_cache_size = config['configurations']['config']['mmap_cache_size']
compiled_expression_cache_size = config['configurations']['config']['compiled_expression_cache_size']
path = config['configurations']['config']['path']
tmp_path = config['configurations']['config']['tmp_path']
user_files_path = config['configurations']['config']['user_files_path']
users_xml_path = config['configurations']['config']['users_xml_path']
user_directories_users_xml_path = config['configurations']['config']['user_directories_users_xml_path']
user_directories_local_directory = config['configurations']['config']['user_directories_local_directory']
default_profile = config['configurations']['config']['default_profile']
custom_settings_prefixes = config['configurations']['config']['custom_settings_prefixes']
default_database = config['configurations']['config']['default_database']
timezone = config['configurations']['config']['timezone']
mlock_executable = config['configurations']['config']['mlock_executable']
remap_executable = config['configurations']['config']['remap_executable']
include_from = config['configurations']['config']['include_from']
zookeeper = config['configurations']['config']['zookeeper']
builtin_dictionaries_reload_interval = config['configurations']['config']['builtin_dictionaries_reload_interval']
max_session_timeout = config['configurations']['config']['max_session_timeout']
default_session_timeout = config['configurations']['config']['default_session_timeout']
compression = config['configurations']['config']['compression']
dictionaries_config = config['configurations']['config']['dictionaries_config']
distributed_ddl_path = config['configurations']['config']['distributed_ddl_path']
format_schema_path = config['configurations']['config']['format_schema_path']


#配置文件metrika.xml.j2参数变量
shard_replica_relation = config['configurations']['metrika']['shard_replica_relation']

